package com.example.HBES;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HbesApplicationTests {

	@Test
	void contextLoads() {
	}

}
