package com.example.HBES;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HbesApplication {

	public static void main(String[] args) {
		SpringApplication.run(HbesApplication.class, args);
	}

}
